package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class MyLeadsPage extends  BaseClass {
	

	public CreateLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
	public FindLeadPage clickFindLeadTapButton() {
		getDriver().findElement(By.linkText("Find Leads")).click();
		return new FindLeadPage();
	}
}
