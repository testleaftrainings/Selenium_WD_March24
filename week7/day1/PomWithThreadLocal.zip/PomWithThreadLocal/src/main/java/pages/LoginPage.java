package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class LoginPage extends BaseClass {
	

	public LoginPage enterUserName(String userName) {
		getDriver().findElement(By.id("username")).sendKeys(userName);
		return this;
	}
	public LoginPage enterPassword(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this;
	}
	public HomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
//		HomePage hp =new HomePage();
//		return hp;
		return new HomePage();
	}
}
