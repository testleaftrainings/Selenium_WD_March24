package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class HomePage extends BaseClass {
	
	public MyHomePage clickCrmsfaHyperLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	public void verifyLogin() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
}
