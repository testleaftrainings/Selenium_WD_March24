package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;


public class DeleteLead extends BaseClass{
	
	@Test
	public void runLoginVerify() throws InterruptedException {
		
		new LoginPage()
		.enterUserName("Demosalesmanager")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmsfaHyperLink()
		.clickLeadsTap()
		.clickFindLeadTapButton()
		.enterLeadId()
		.clickFindLeadButton()
		.clickFirstResultingLead()
		.clickDeleteButton()
		.clickFindLeadTapButton()
		.enterLeadId()
		.clickFindLeadButton()
		.VerifyDeletedLead();
		
		
		
	}

}
