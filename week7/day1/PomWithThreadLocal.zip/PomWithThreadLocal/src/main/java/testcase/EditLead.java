package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;
import utills.ReadExcel;


public class EditLead extends BaseClass{
	@BeforeTest
	public void setDetails() {
		 excelFileName="EditLead";
	}
	@Test(dataProvider = "sendData")
	public void runLoginVerify(String userName,String password,String mobileNumber,String companyName) throws InterruptedException {
		
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfaHyperLink()
		.clickLeadsTap()
		.clickFindLeadTapButton()
		.clickPhoneTap()
		.enterYourPhoneNumber(mobileNumber)
		.clickFindLeadButton()
		.clickFirstResultingLead()
		.clickEditButton()
		.changeMyCompanyName(companyName)
		.clickUpdateButton()
		.verifyViewLeadPage();
		
	}

}
