package utills;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
public static String[][] getData(String excelFileName) throws IOException {
	//set up the exccel path
	XSSFWorkbook book=new XSSFWorkbook("./data/"+excelFileName+".xlsx");
	//To get Sheet name
	XSSFSheet sheet = book.getSheet("Sheet1");
	//to get the row count
	int rowCount = sheet.getLastRowNum();
	//To get column count
	short columnCount = sheet.getRow(0).getLastCellNum();
	String[][] data=new String[rowCount][columnCount];
	
	for (int i = 1; i <=rowCount; i++) {
		for (int j = 0; j < columnCount; j++) {
			String stringCellValue = sheet.getRow(i).getCell(j).getStringCellValue();
			System.out.println(stringCellValue);
			data[i-1][j]=stringCellValue;
		}
		
	}
	//close work book
	book.close();
	return data;
}
}
