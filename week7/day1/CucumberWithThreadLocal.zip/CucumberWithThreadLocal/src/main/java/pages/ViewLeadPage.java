package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends BaseClass {
	 @Then("ViewLead page should be displayed")
	public ViewLeadPage verifyViewLeadPage() {
		String actualTitle = getDriver().getTitle();
		String expectedTitle = "View Lead | opentaps CRM";
		if (actualTitle.equals(expectedTitle)) {
			System.out.println("Create Lead Created Successfully");
		}
		
		return this;
	}
	 
	  	
	public void toGetCreateLeadId(){
		String text = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println(text);
		//i want to print only digit
		String replaceAll = text.replaceAll("[^0-9]", "");
		System.out.println("The Create Lead id is  "+replaceAll);
	}
	public EditLeadPage clickEditButton() {
		getDriver().findElement(By.linkText("Edit")).click();
		return new EditLeadPage();
	}
	public MyLeadsPage clickDeleteButton() {
		getDriver().findElement(By.linkText("Delete")).click();
		return new MyLeadsPage();
	}
}
