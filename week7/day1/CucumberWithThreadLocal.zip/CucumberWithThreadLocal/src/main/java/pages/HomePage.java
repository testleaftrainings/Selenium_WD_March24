package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePage extends BaseClass {
	@When("Click on crmsfa hyper link")
	public MyHomePage clickCrmsfaHyperLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	public void verifyLogin() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
	@Then("HomePage should be displayed")
	public void verifyHomePage() {
		String actualTitle="Leaftaps - TestLeaf Automation Platform";
		String expectedTitle = getDriver().getTitle();
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Home page verified successfully");
		}else {
			System.out.println("Home page not verified successfully");
		}
		String text = getDriver().findElement(By.tagName("h2")).getText();
		System.out.println(text);
	}
    @But("error message should be displayed")
    public void verifyErrorMsg() {
    	String text = getDriver().findElement(By.id("errorDiv")).getText();
    	System.out.println(text);
    }
}
