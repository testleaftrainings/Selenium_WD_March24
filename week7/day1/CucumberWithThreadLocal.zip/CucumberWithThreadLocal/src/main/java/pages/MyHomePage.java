package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyHomePage extends BaseClass{
@When("click on Leads tap")
public MyLeadsPage clickLeadsTap() {
	getDriver().findElement(By.linkText("Leads")).click();
	return new MyLeadsPage();
}
@Then("MyHomePage should be displayed")
	public void verifyMyHomePage() {
		String actualTitle="My Home | opentaps CRM";
		String expectedTitle = getDriver().getTitle();
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("MyHomePage verified successfully");
		}else {
			System.out.println("MyHomepage not verified successfully");
		}
	}
}
