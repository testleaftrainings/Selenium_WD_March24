package runner;

import base.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/CreateLead.feature",
                  glue="pages",
                  monochrome = true,
                  publish = true)
public class CreateLeadRunner extends BaseClass{

}
